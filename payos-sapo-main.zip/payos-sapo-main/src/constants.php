<?php

define('PAYOS_NOT_FOUND_ORDER_CODE', 101);
define('SAPO_ORDER_PAID_MESSAGE', 'paid');